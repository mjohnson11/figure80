# This is a binder to get a jumpstart analyzing the data from Johnson et al. 2019
